# FONTS

- Poppins (400 and 700) - https://fonts.google.com/specimen/Poppins

# COLORS

- background color: #EFF0F6
- border color: #d7d6fc
- primary purple: #6B00F5
- Pattens Blue: #e1f0fe
- Ghost White: #f7f7ff
- White Ice: #defef0
